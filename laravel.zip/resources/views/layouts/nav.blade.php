<div class="blog-masthead">
    <div class="container">
        <nav class="nav">
            <a class="nav-link active" href="#">Home</a>
            @if(!Auth::check())

                <a class="nav-link" href="/laravel/index.php/register">Register</a>

                <a class="nav-link" href="/laravel/index.php/login">Login</a>


            @endif

            @if(Auth::check())
                <a class="nav-link" href="/laravel/index.php/myposts/{{Auth::user()->id}}">MyPosts</a>

                <a class="nav-link" href="/laravel/index.php/logout">Logout</a>

                <a class="nav-link ml-auto" href="#">{{ Auth::user()->name }}</a>

                <a class="nav-link" href="/laravel/index.php/posts/create">Create Post</a>

            @endif
        </nav>
    </div>
</div>
