<html>

    <head>

    </head>

    <body>
            Welcome to the Laracast!{{ $user->name }}
    </body>

</html>