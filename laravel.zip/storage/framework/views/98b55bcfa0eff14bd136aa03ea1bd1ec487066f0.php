<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">

        <div class="container">

            <div class="blog-post">

                <a href="/laravel/index.php/posts/<?php echo e($post->id); ?>">

                    <h2 class="blog-post-title"><?php echo e($post->title); ?></h2>

                </a>

                <p class="blog-post-meta">
                    <?php echo e($post->User->name); ?>


                    <?php echo e($post->created_at->toFormattedDateString()); ?>


                </p>
                <div><?php echo $post->body; ?></div>
                </br>

                <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <img class="img_uploude" src='/laravel/storage/app/public/kiarash/<?php echo $img['post_id']; ?>.png'>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <form method="post" action="/laravel/show_delete/<?php echo e($post->id); ?>">

                <?php echo e(csrf_field()); ?>


                <div class="form-group">

                    <label for="title">Title:</label>

                    <input value="<?php echo e($post->title); ?>" type="text" class="form-control" id="title" name="title" >

                </div>

                <div class="form-group">

                    <label for="body">Body:</label>

                    <textarea name="body" class="form-control tinymce"><?php echo $post->body; ?></textarea>

                </div>

                <div class="form-group">

                    <button type="submit" class="btn btn-primary update">Update</button>

                </div>

                <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </form>

            <div class="form-group">
                <a class="btn btn-primary delete" href="/laravel/index.php/delete/<?php echo e($post->id); ?>">Delete</a>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>