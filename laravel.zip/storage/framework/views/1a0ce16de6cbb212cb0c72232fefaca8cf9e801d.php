<div class="blog-post">

    <a href="/laravel/edit/<?php echo e($post->id); ?>">

        <h2 class="blog-post-title"><?php echo e($post->title); ?></h2>
    </a>

    <p class="blog-post-meta">

        <?php echo e($post->User->name); ?>


        <?php echo e($post->created_at->toFormattedDateString()); ?>


    </p>

    <?php echo $post->body; ?>



</div>
