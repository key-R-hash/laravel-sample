<div class="container">

    <div class="row">

        <div class="col-sm-8 blog-main">
            <footer class="blog-footer">
                <p>Blog template built for <a href="https://getbootstrap.com">Bootstrap</a> by <a href="https://twitter.com/mdo">@mdo</a>.</p>
                <p>
                    <a href="#">Back to top</a>
                </p>
            </footer>
        </div>
    </div>
</div>