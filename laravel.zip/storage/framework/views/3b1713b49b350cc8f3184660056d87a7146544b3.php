<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">

        <div class="container">

            <div class="blog-post">

                <a href="/laravel/index.php/posts/<?php echo e($post->id); ?>">

                    <h2 class="blog-post-title"><?php echo e($post->title); ?></h2>

                </a>

                <p class="blog-post-meta">
                    <?php echo e($post->User->name); ?>


                    <?php echo e($post->created_at->toFormattedDateString()); ?>


                </p>
                <?php echo e($post->body); ?>

            </div>

            <form method="post" action="/laravel/index.php/posts">

                <?php echo e(csrf_field()); ?>


                <div class="form-group">

                    <label for="title">Title:</label>

                    <input value="<?php echo e($post->title); ?>" type="text" class="form-control" id="title" name="title" >

                </div>

                <div class="form-group">

                    <label for="body">Body:</label>

                    <textarea name="body" class="form-control"><?php echo e($post->body); ?></textarea>

                </div>

                <div class="form-group">

                    <button type="submit" class="btn btn-primary update">Update</button>

                </div>

                <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </form>

            <div class="form-group">

                <input href="/laravel/index.php/delete/<?php echo e($post->id); ?>" type="submit" class="btn btn-primary delete">

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>