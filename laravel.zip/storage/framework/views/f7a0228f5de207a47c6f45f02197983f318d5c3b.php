<html>

    <head>

    </head>

    <body>
            Welcome to the Laracast!<?php echo e($user->name); ?>

    </body>

</html>