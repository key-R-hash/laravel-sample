<div class="blog-post">

    <a href="/laravel/posts/<?php echo e($post->id); ?>">

        <h2 class="blog-post-title"><?php echo e($post->title); ?></h2>
    </a>

    <p class="blog-post-meta">

        <?php echo e($post->User->name); ?>


        <?php echo e($post->created_at->toFormattedDateString()); ?>


    </p>

    <div style="height: 60px; overflow: hidden">

        <?php

            $body =$post->body;
                echo $body;
        ?>

    </div>
    <a href="/laravel/posts/<?php echo e($post->id); ?>">"Read More"</a>
</div>
