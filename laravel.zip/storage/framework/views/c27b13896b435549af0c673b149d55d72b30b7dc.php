<div class="blog-masthead">
    <div class="container">
        <nav class="nav">
            <a class="nav-link active" href="#">Home</a>
            <?php if(!Auth::check()): ?>

                <a class="nav-link" href="/laravel/index.php/register">Register</a>

                <a class="nav-link" href="/laravel/index.php/login">Login</a>


            <?php endif; ?>

            <?php if(Auth::check()): ?>
                <a class="nav-link" href="/laravel/index.php/myposts/<?php echo e(Auth::user()->id); ?>">MyPosts</a>

                <a class="nav-link" href="/laravel/index.php/logout">Logout</a>

                <a class="nav-link ml-auto" href="#"><?php echo e(Auth::user()->name); ?></a>

                <a class="nav-link" href="/laravel/index.php/posts/create">Create Post</a>

            <?php endif; ?>
        </nav>
    </div>
</div>
