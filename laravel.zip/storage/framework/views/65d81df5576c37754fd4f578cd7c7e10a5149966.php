<?php $__env->startSection('content'); ?>
    <div class="col-sm-8 blog-main">
    <div class="container">
        <div class="blog-post">
            <a href="/laravel/index.php/posts/<?php echo e($post->id); ?>">
                <h2 class="blog-post-title"><?php echo e($post->title); ?></h2>
            </a>
            <p class="blog-post-meta">
                <?php echo e($post->User->name); ?>


                <?php echo e($post->created_at->toFormattedDateString()); ?>


            </p>
            <?php echo $post->body; ?>


        <br>
        <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img class="img_uploude" src='/laravel/storage/app/public/kiarash/<?php echo $img['post_id']; ?>.png'>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

        <hr>

        <div class="comments">

            <ul class="list-group">
                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li class="list-group-item">
                        <strong>
                            <?php echo e($comment->created_at->diffForHumans()); ?>:&nbsp;
                        </strong>

                        <?php echo $comment->body; ?>

                    </li>



                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>

        <hr>

        <div >

            <div class="card-block">

                <form method="post" action="/laravel/index.php/posts/<?php echo e($post->id); ?>/comments">

                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">

                            <textarea name="body" placeholder="Your comment here." class="form-control"></textarea>


                    </div>

                    <div class="form-group">

                        <button type="submit" class="btn btn-primary">Add Comment</button>

                    </div>

                </form>

                <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>