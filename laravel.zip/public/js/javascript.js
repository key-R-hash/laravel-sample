var data = {
    title:"kiarash"
}


new Vue({
    el:"#kiarash",
    data: data

})